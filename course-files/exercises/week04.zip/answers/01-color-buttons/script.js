function changeColor(color) {
    document.querySelector("body").style.backgroundColor = color;
}
