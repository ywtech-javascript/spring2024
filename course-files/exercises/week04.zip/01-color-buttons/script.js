function makeBlue() {
    document.querySelector("body").style.backgroundColor = "#51D6FF";
}
