console.log("Hello world!");

// note: this is an infinite loop. This code will crash your browser:
// while (true) {
//     console.log(''Hello world!');
// }
