function defaultTheme () {
    console.log("remove all classes from the body");
}

function oceanTheme () {
    console.log("apply ocean class to the body");
}

function desertTheme () {
    console.log("apply desert class to the body");
}

function highContrastTheme () {
    console.log("apply high-contrast class to the body");
} 