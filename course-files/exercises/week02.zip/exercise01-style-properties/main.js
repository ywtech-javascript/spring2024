function makeRed () {
    console.log("turn first div red");
}

function makeBlue () {
    console.log("turn 2nd div blue");
}

function makePink () {
    console.log("turn 3rd div pink");
}

function makeOrange () {
    console.log("turn 4th div orange");
}

