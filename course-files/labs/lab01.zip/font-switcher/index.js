function makeBigger() {
    console.log("make bigger");
}

function makeSmaller() {
    console.log("make smaller");
}
