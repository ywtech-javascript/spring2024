function evenOrOdd(num) {
    // this function should return the string "even"
    // if the value held in the num parameter
    // is even and "odd" if it is odd.
}

console.log("5:", evenOrOdd(5));
console.log("18:", evenOrOdd(18));
console.log("125:", evenOrOdd(125));
